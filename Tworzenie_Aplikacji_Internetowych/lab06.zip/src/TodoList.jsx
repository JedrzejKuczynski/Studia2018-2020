import React, {useState, useEffect} from 'react'
import uuid from 'uuid'

export const TodoList = props => { 

    // const data = ["ala", "ula", "ola"]
    // const items = data.map((d, i) => <li key={i}>{d}</li>)
    //const { cos, a, b } = props

    const [counter, setCounter] = useState(0)
    const [name, setName] = useState("TODO")
    const [activity, setActivity] = useState("")
    const [data, setData] = useState([
        {_id: "a1", text: "zrob obiad"},
        {_id: "a2", text: "wynies smieci"}
    ])
    const [loading, setLoading] = useState(false)
    const [error, setError] = useState("")

    useEffect(() => {
        const fetchData = async () => {
            setLoading(true)
            try {
            const response = await fetch("http://localhost:3001/api/todos")
            const todos = await response.json()
            setData(todos)
            } catch (err) {
                setError(err)
            }
            setLoading(false)
        } 

        fetchData()
        
        return () => {
            console.log("zmiana countera")
        };
    }, [])
    

    const items = data.map((d, i) => <li key={d._id}>{d.text}</li>)

    const handleSubmit = e => {
        e.preventDefault()

        // zapisac na liscie

        setData([...data, {_id: uuid.v4(), text: activity}])

        // wyczysc input
        setActivity("")
    }

    return (<div>
        <h2>Todo</h2>
        <br />
        <small>{loading ? "loading..." : ""}</small>
        {error}
        <p>Counter: {counter}</p>
        <button onClick={e => setCounter(counter + 1)}>Inc</button>
        <hr />
        <form onSubmit={handleSubmit}>
            <input type="text" value={activity} onChange={e => setActivity(e.target.value)}></input>
            <button>Save</button>
        </form>
        <ul>{items}</ul>
    </div>)
}


export default TodoList
