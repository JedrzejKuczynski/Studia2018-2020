import React, {useEffect, useState} from 'react'

export const Watch = () => {

    const [time, setTime] = useState(new Date().getTime())

    useEffect(() => {
        const interval = setInterval(() => {
            setTime(new Date().getTime())
        }, 1000);
        return () => clearInterval(interval);
      }, []);


    return (
        <div>
            <p>{time}</p>
        </div>
    )
}

export default Watch
