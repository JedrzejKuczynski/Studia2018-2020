import React, {useState, useEffect} from 'react'
import uuid from 'uuid'

export const TodoList = props => { 

    // const data = ["ala", "ula", "ola"]
    // const items = data.map((d, i) => <li key={i}>{d}</li>)
    //const { cos, a, b } = props

    const [counter, setCounter] = useState(0)
    const [name, setName] = useState("TODO")
    const [activity, setActivity] = useState("")
    const [data, setData] = useState([
        {_id: "a1", text: "zrob obiad"},
        {_id: "a2", text: "wynies smieci"}
    ])
    const [loading, setLoading] = useState(false)
    const [error, setError] = useState("")

    const api_url = "http://localhost:3001/api/todos/"

    const fetchData = async (url="http://localhost:3001/api/todos/", data={}) => {
        setLoading(true)
        try {
            const response = await fetch(url, data) // "http://localhost:3001/api/todos"
            const todos = await response.json()
            setData(todos)
        } catch (err) {
            setError(err)
        }
        setLoading(false)
    } 

    useEffect(() => {
        fetchData()
        
        return () => {
            console.log("zmiana countera")
        };
    }, [])
    

    // PUT
    const items = data.map((d, i) => (
        <li key={d._id}>
            <input type="checkbox" checked={d.done} onClick={e => fetchData
        (api_url + d._id, {method: "PUT"})}></input> 
            <label>{d.text}</label>
            <button onClick={e => fetchData(api_url + d._id, {method: "DELETE"})}>X</button>
        </li>))

    const handleSubmit = e => {
        e.preventDefault()

        // zapisac na liscie
        setData([...data, {_id: uuid.v4(), text: activity}])

        // wyczysc input
        setActivity("")
    }

    return (<div>
        <h2>Todo</h2>
        <br />
        <small>{loading ? "loading..." : ""}</small>
        {error}
        <p>Counter: {counter}</p>
        <button onClick={e => setCounter(counter + 1)}>Inc</button>
        <hr />
        <form onSubmit={handleSubmit}>
            <input type="text" value={activity} onChange={e => setActivity(e.target.value)}></input>
            <button onClick={e => fetchData(api_url,  {method: "POST",
            headers: {
                "Content-Type": "application/json"
            }, 
            body: JSON.stringify({text: activity})
        }
    )}>Save</button>
        </form>
        <ul>{items}</ul>
    </div>)
}


export default TodoList
