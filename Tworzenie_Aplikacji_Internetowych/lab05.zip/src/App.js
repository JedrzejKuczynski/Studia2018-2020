import React from 'react';
import logo from './logo.svg';
import './App.css';
import Cos from './Cos';
import Fos from './Fos';

function App() {

  const cos = "Ala ma kota"

  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        

        <Cos name="Ala" age="21" />
        <Fos cos="Funkcyjne" a="234" b={cos} />
      </header>
    </div>
  );
}

export default App;
