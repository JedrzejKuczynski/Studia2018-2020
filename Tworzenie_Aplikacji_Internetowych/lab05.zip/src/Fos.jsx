import React from 'react'

export const Fos = (props) => { 

    const data = ["ala", "ula", "ola"]

    const items = data.map((d, i) => <li key={i}>{d}</li>)

    const { cos, a, b } = props
    return <div> {cos} tez dziala! {a}! {b}! <br /> <ul>{items}</ul></div>
}


export default Fos
