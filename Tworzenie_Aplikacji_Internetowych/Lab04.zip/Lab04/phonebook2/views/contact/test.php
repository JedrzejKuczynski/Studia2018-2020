<h1>Ala ma kota!</h1>
<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Iure vitae eaque suscipit eligendi non doloribus assumenda,
    veritatis aspernatur labore, doloremque cumque.Veritatis laboriosam earum aliquid, illum ipsa ab vitae natus.</p>
<?= $cos . ' ' . $cos2 . ' ' . $cos3 ?>
<?php foreach ($cos4 as $value): ?>
<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Fugiat quas laborum quo impedit exercitationem dolorem quae
    veniam dolore eligendi temporibus debitis, ex nobis ducimus velit consectetur totam vero consequuntur alias.</p>
<?= $value->firstname ?> <br>
<?php endforeach; ?>