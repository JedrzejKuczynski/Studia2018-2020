<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=sql7.freemysqlhosting.net;dbname=sql7312902',
    'username' => 'sql7312902',
    'password' => 'FILRMpNW83',
    'charset' => 'utf8',

    // Schema cache options (for production environment)
    //'enableSchemaCache' => true,
    //'schemaCacheDuration' => 60,
    //'schemaCache' => 'cache',
];
