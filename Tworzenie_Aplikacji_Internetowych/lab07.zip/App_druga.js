import React, { useState } from "react";
import { Button, FlatList, StyleSheet, TextInput, View } from "react-native";
import uuid from "uuid";
import TodoItem from "./components/TodoItem";

export default function App() {
  const [todo, setTodo] = useState("");
  const [list, setList] = useState([{ id: uuid.v4(), value: "umyć żęby" }]);

  const addTodo = () => {
    setList(currentList => [...currentList, { id: uuid.v4(), value: todo }]);
  };

  const deleteTodo = id => {
    setList(currentList => {
      return currentList.filter(item => item.id !== id);
    });
  };

  return (
    <View style={styles.container}>
      <View style={styles.formContainer}>
        <TextInput
          onChangeText={text => setTodo(text)}
          style={styles.input}
          placeholder="wpisz coś"
        />
        <Button title="Dodaj" onPress={addTodo} />
      </View>
      <FlatList
        keyExtractor={item => item.id}
        data={list}
        renderItem={itemData => (
          <TodoItem
            onDeleteTodo={deleteTodo}
            id={itemData.item.id}
            value={itemData.item.value}
          />
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "flex-start",
    padding: 40
  },
  myText: {
    fontSize: 40
  },
  formContainer: {
    flexDirection: "row",
    marginBottom: 30
  },
  input: {
    borderBottomColor: "#ddd",
    borderBottomWidth: 1,
    fontSize: 30,
    width: "80%"
  }
});
