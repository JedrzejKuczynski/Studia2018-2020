import React, { useState } from 'react';
import { StyleSheet, Text, View, Button, TextInput, Keyboard, ScrollView, FlatList } from 'react-native';
import uuid from "uuid";
import TodoItem from "./components/TodoItem"
import TodoInput from "./components/TodoInput"

export default function App() {

  const [todo, setTodo] = useState("")
  const [list, setList] = useState([{id: uuid.v4(), value: "umyć zęby"}])

  const addTodo = text => {
    console.log("Dodawanie...", text)
    setList(currentList => [...currentList, {id: uuid.v4(), value: text}])
  }

  const deleteTodo = (id) => {
    setList(currentList => {
      return currentList.filter(item => item.id != id)
    })
  }


  return (
    <View style={styles.container}>
      <TodoInput  onAddTodo={addTodo} />
      <FlatList
        keyExtractor={item => item.id}
        data={list}
        renderItem={itemData => (<TodoItem onDeleteTodo={deleteTodo} id={itemData.item.id} value={itemData.item.value} />)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'flex-start',
    padding: 40
  }
});
