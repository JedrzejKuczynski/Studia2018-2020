import React from 'react'
import {Text, View, StyleSheet, TouchableOpacity} from "react-native"

const TodoItem = (props) => {
    return (
        <TouchableOpacity onPress={() => props.onDeleteTodo(props.id)}>
            <View style={styles.itemContainer}>
                <Text key={props.id}>{props.value}</Text>
            </View>
        </TouchableOpacity>
    )
}

const styles = StyleSheet.create({
    itemContainer: {
        width: "100%",
        padding: 10,
        marginBottom: 10,
        borderWidth: 1,
        borderColor: "black",
        backgroundColor: "#ddd"
    }
})

export default TodoItem
