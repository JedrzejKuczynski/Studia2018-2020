import React, {useState} from 'react'
import {View, TextInput, Button, StyleSheet} from "react-native"

const TodoInput = (props) => {

    const [todo, setTodo] = useState("")

    return (
        <View style={styles.formContainer}>
            <TextInput style={styles.input} placeholder="Wpisz coś!" value={todo} onChangeText={text => setTodo(text)}/>
            <Button title="Dodaj" onPress={() => {props.onAddTodo(todo); setTodo("")}} />
        </View>
    )
}

export default TodoInput

const styles = StyleSheet.create({
    input: {
      borderBottomColor: "#ddd",
      borderBottomWidth: 1,
      fontSize: 30,
      width: "80%"
    },
    formContainer: {
      flexDirection: "row",
      marginBottom: 30
    }
  });
